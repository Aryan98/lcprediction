## See:

https://eliasvansteenkiste.github.io/machine%20learning/lung-cancer-pred/

GenerateSolution.txt

WinningModelDocumentation.pdf
